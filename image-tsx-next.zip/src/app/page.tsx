"use client"
import Image from "next/image";
import styles from "./page.module.css";


const IndexPage: React.FC = () => {

  //const url = 'https://sdbooth2-production.s3.amazonaws.com/s1s5rnxoj50uf974ytgp7pgdyedd'
  const fetchData = async () => {
    try {
      const response = await fetch('https://sdbooth2-production.s3.amazonaws.com/s1s5rnxoj50uf974ytgp7pgdyedd');
      if (!response.ok) {
        throw new Error('Network response was not ok');
      }

      const blobData = await response.blob()
      const url = window.URL.createObjectURL(new Blob([blobData]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', 'image.jpg');
      link.click();
    } catch (error) {
      console.log("Error")
    }
    // fetch(url, {
    //   method: 'GET'
    // })
    //   .then(response => response.blob())
    //   .then(blob => {
    //     const url = window.URL.createObjectURL(new Blob([blob]));
    //     const link = document.createElement('a');
    //     link.href = url;
    //     link.setAttribute('download', 'image.jpg');
    //     link.click();
    //   })
  };


  return (
    <div className={styles.main}>
      <h1>Fetch API Example in Next.js with TypeScript</h1>
      <button onClick={fetchData}>
        Download
      </button>
    </div>
  );
};

export default IndexPage;