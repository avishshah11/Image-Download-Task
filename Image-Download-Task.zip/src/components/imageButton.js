import React from "react";
import "./imageButton.css";

//Main function
const ImageButton = () => {

    let imageUrl = "https://sdbooth2-production.s3.amazonaws.com/s1s5rnxoj50uf974ytgp7pgdyedd"

    //Event Handler
    const handleClick = () => {
        fetch(imageUrl)
            .then(response => response.blob())
            .then(blob => {
                const url = window.URL.createObjectURL(new Blob([blob]));
                const link = document.createElement('a');
                link.href = url;
                link.setAttribute('download', 'image.jpg');
                link.click();
            })
            .catch(error => {
                console.error('Error downloading the image:', error);
            });
    }

    return (
        <div className="container">
            <h3 className="header">Download Image</h3>
            <div className="image">
                <button
                    className="image-button"
                    onClick={handleClick}
                >
                    Download
                </button>
            </div>
        </div>
    )
}

export default ImageButton;