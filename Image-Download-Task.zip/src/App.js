import React from 'react';
import ImageButton from './components/imageButton';

function App() {
  return (
    <ImageButton />
  );
}

export default App;
